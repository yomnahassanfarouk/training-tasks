let x =parseInt(prompt('number 1'))
let y =parseInt(prompt('number 2'))

if(x >0 && y >0){
    document.write('1&2=posstive')
}
else if( x>0 && y<0){
    document.write('1=posstive,2=negative')
}
else if(x<0 && y>0){
    document.write('1=negative ,2postive')
}
else if(x<0 && y<0){
    document.write('1&2=negative')
}

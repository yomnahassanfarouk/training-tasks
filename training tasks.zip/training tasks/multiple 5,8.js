let x=parseInt(prompt('enternumber'))
if(x%5==0){
    document.write('5')}

else if(x%8==0){
    document.write('8')
}

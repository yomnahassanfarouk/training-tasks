let x=parseInt(prompt('Number 1='))
let y=parseInt(prompt('Number 2='))
let sum=x+y
if(x==50||y==50||sum==50)
{
document.write('T')
}
else{ 
document.write('F')
}
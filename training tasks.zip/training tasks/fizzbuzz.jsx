for (var i=1; i <= 20; i++){
    if (i % 15==0)
    document.write("Fizz buzz");
    else if (i %3== 0)
    document.write("fizz");
    else if (i%5== 0)
    document.write("buzz");
    else
    document.write(i);
}
let x=parseInt(prompt('Number 1='))
let y=parseInt(prompt('Number 2='))
let sum=x+y


document.write('sum='+sum)
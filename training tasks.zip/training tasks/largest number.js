let x =parseInt(prompt("Enter n1 "))
let y =parseInt(prompt("Enter n2"))
let z =parseInt(prompt("Enter n3"))
if(x>y&&x>z){
    document.write('n1 is the largest'+x)
}

else if(y>x&&y>z)
{
    document.write('n2 is the largest'+y)}

else if(z>x&&z>y){
    document.write('n3 is the largest'+z)}
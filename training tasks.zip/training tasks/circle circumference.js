let x =parseInt(prompt('ENTER RADIUS'))
let circumference  =2*x*3.14
document.write('circumference ='+circumference )
let area =3.14*Math.pow(n,2)
document.write('Area= '+area)
